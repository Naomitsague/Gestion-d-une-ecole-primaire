@extends('app')

@section('content')
<style>
    /* Styles personnalisés pour la page de connexion */
    .login-container {
        display: flex;
        justify-content: center;
        align-items: center;
        height: 100%;
        background: linear-gradient(135deg, #6e8efb, #a777e3);
        padding: 20px;
    }

    .login-card {
        background: rgba(255, 255, 255, 0.95);
        border-radius: 15px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.2);
        padding: 40px;
        width: 100%;
        max-width: 450px;
        backdrop-filter: blur(10px);
        transition: transform 0.3s ease;
    }

    .login-card:hover {
        transform: translateY(-5px);
    }

    .login-card h2 {
        color: #333;
        font-weight: 700;
        margin-bottom: 30px;
        text-align: center;
        font-size: 28px;
    }

    .form-group {
        position: relative;
        margin-bottom: 25px;
    }

    .form-group i {
        position: absolute;
        left: 15px;
        top: 50%;
        transform: translateY(-50%);
        color: #6e8efb;
        font-size: 18px;
    }

    .form-control {
        padding-left: 40px;
        border-radius: 10px;
        border: 1px solid #ddd;
        height: 50px;
        transition: border-color 0.3s, box-shadow 0.3s;
    }

    .form-control:focus {
        border-color: #6e8efb;
        box-shadow: 0 0 8px rgba(110, 142, 251, 0.3);
        outline: none;
    }

    .form-control.is-invalid {
        border-color: #dc3545;
    }

    .invalid-feedback {
        font-size: 0.875rem;
        margin-top: 5px;
    }

    .btn-login {
        background: linear-gradient(90deg, #6e8efb, #a777e3);
        border: none;
        border-radius: 10px;
        padding: 12px;
        font-size: 18px;
        font-weight: 600;
        width: 100%;
        transition: background 0.3s, transform 0.2s;
    }

    .btn-login:hover {
        background: linear-gradient(90deg, #5a78e3, #8f5ed0);
        transform: scale(1.05);
    }

    .btn-login:active {
        transform: scale(0.95);
    }

    .form-label {
        font-weight: 500;
        color: #555;
        margin-bottom: 8px;
    }
</style>

<div class="login-container">
    <div class="login-card">
        <h2>Connexion</h2>
        <form method="POST" action="{{ route('login') }}">
            @csrf

            <!-- Champ Email -->
            <div class="form-group">
                <label for="email" class="form-label">Adresse Email</label>
                <i class="fas fa-envelope"></i>
                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autofocus>
                @error('email')
                    <span class="invalid-feedback" role="alert">
                        {{ $message }}
                    </span>
                @enderror
            </div>

            <!-- Champ Mot de passe -->
            <div class="form-group">
                <label for="password" class="form-label">Mot de passe</label>
                <i class="fas fa-lock"></i>
                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required>
                @error('password')
                    <span class="invalid-feedback" role="alert">
                        {{ $message }}
                    </span>
                @enderror
            </div>

            <!-- Bouton Soumettre -->
            <div class="form-group">
                <button type="submit" class="btn btn-login">Se connecter</button>
            </div>
        </form>
    </div>
</div>

<!-- Inclure Font Awesome pour les icônes -->
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
@endsection