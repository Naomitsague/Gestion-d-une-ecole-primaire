<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Gestion des Matières</title>
  <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
  <style>
    body {
      background-color: #f8f9fa;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }

    .card-header {
      background: linear-gradient(135deg, #0d6efd, #0b5ed7);
      color: white;
    }

    h2 {
      font-weight: 600;
    }

    .action-card {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      padding: 6px 12px;
      border-radius: 8px;
      transition: all 0.3s ease;
      cursor: pointer;
      min-width: 100px;
      font-size: 0.85rem;
      font-weight: 600;
      text-align: center;
      color: white;
      text-decoration: none;
      box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    }

    .action-card i {
      margin-right: 6px;
    }

    .action-edit {
      background-color: #0d6efd;
    }

    .action-edit:hover {
      background-color: #0b5ed7;
      transform: scale(1.05);
    }

    .action-delete {
      background-color: #dc3545;
    }

    .action-delete:hover {
      background-color: #bb2d3b;
      transform: scale(1.05);
    }

    .action-form {
      display: inline-block;
      margin: 0;
    }

    .action-form button {
      all: unset;
      width: 100%;
      height: 100%;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      border-radius: 8px;
      font-weight: 600;
      font-size: 0.85rem;
      color: inherit;
      cursor: pointer;
    }

    .pagination {
      margin-top: 1rem;
    }

    .card {
      border: none;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }

    .table thead th {
      vertical-align: middle;
    }
  </style>
</head>
<body>

<div class="container py-5">
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h2 class="mb-0">Liste des matières</h2>
      <a href="{{ route('matieres.create') }}" class="btn btn-light text-primary fw-bold shadow-sm">
        <i class="fas fa-plus"></i> Ajouter une matière
      </a>
    </div>

    <div class="card-body">
      @if(session('success'))
        <div class="alert alert-success">
          {{ session('success') }}
        </div>
      @endif

      <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle bg-white">
          <thead class="table-light text-center">
            <tr>
              <th>Nom de la matière</th>
              <th>Classes associées</th>
              <th>Section</th>
              <th>Modifier</th>
              <th>Supprimer</th>
            </tr>
          </thead>
          <tbody>
            @foreach($matieres as $matiere)
              <tr>
                <td>{{ $matiere->nom_matiere }}</td>
                <td>
                  @foreach($matiere->classes as $classe)
                    <span class="badge bg-secondary mb-1">{{ $classe->nom_classe }}</span><br />
                  @endforeach
                </td>
                <td>
                  @foreach($matiere->classes as $classe)
                    <span class="badge bg-info text-dark mb-1">{{ $classe->section->nom_section ?? 'N/A' }}</span><br />
                  @endforeach
                </td>
                <td class="text-center">
                  <a href="{{ route('matieres.edit', $matiere->id_matiere) }}" class="action-card action-edit">
                    <i class="fas fa-edit"></i> Modifier
                  </a>
                </td>
                <td class="text-center">
                  <form action="{{ route('matieres.destroy', $matiere->id_matiere) }}" method="POST" class="action-form" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette matière ?')">
                    @csrf
                    @method('DELETE')
                    <button type="submit" class="action-card action-delete">
                      <i class="fas fa-trash-alt"></i> Supprimer
                    </button>
                  </form>
                </td>
              </tr>
            @endforeach
          </tbody>
        </table>

        <!-- Pagination Bootstrap stylée -->
        <div class="d-flex justify-content-center">
          {{ $matieres->links('pagination::bootstrap-5') }}
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Bootstrap JS -->
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/js/all.min.js"></script>

</body>
</html>
