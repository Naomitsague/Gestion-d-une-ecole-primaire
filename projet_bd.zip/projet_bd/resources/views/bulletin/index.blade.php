<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8" />
    <title>Bulletin Scolaire</title>
    <style>
        @page {
            size: A4;
            margin: 10mm;
        }
        body {
            font-family: 'Helvetica Neue', Arial, sans-serif;
            font-size: 10pt;
            margin: 0;
            padding: 0;
            background: #f5f5f5;
            color: #1a1a1a;
        }
        .container {
            max-width: 760px;
            margin: 10px auto;
            padding: 15px;
            box-sizing: border-box;
            background: #ffffff;
            border-radius: 6px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
            page-break-inside: avoid;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 2px solid #004aad;
        }
        .header-info {
            max-width: 65%;
        }
        .header-info h1 {
            margin: 0 0 5px 0;
            font-size: 20pt;
            color: #004aad;
            font-weight: 700;
        }
        .header-info h2 {
            margin: 3px 0;
            font-size: 14pt;
            color: #333;
            font-weight: 600;
        }
        .header-info p {
            margin: 2px 0;
            font-size: 10pt;
            color: #555;
        }
      
.photo-container {
    flex-shrink: 0;
    width: 100px;
    height: 120px;
    border: 2px solid #004aad;
    background-color: #e8ecef;
    box-shadow: 2px 2px 6px rgba(0, 0, 0, 0.15);
    position: relative;
    overflow: hidden;
    border-radius: 4px;
}

.photo-container::before {
    content: "";
    position: absolute;
    top: -8px;
    left: 6px;
    width: 20px;
    height: 30px;
    border: 2px solid #666;
    border-radius: 5px;
    border-bottom: none;
    border-left: none;
    background: transparent;
    box-shadow: 2px 0 0 #666, 2px 28px 0 #666;
    transform: rotate(-20deg);
    z-index: 10;
}

.photo-container img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    display: block;
    border-radius: 4px;
}

        .student-info {
            margin-bottom: 12px;
            font-size: 10pt;
            line-height: 1.4;
            background: #f8f9fa;
            padding: 8px;
            border-radius: 5px;
        }
        .student-info p {
            margin: 3px 0;
        }
        .student-info strong {
            color: #004aad;
        }
        .grades-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 15px;
            font-size: 10pt;
        }
        .grades-table th, .grades-table td {
            border: 1px solid #d1d5db;
            padding: 5px 8px;
            text-align: left;
            vertical-align: middle;
        }
        .grades-table th {
            background-color: #004aad;
            color: #fff;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 9pt;
        }
        .grades-table td {
            background-color: #f8f9fa;
        }
        .grades-table tr:nth-child(even) td {
            background-color: #ffffff;
        }
        .general-results {
            font-weight: bold;
            font-size: 11pt;
            margin-bottom: 12px;
            padding: 8px;
            background: #e6f0fa;
            border-left: 4px solid #004aad;
            border-radius: 4px;
        }
        .general-results p {
            margin: 3px 0;
        }
        .general-results .mention {
            color: #d32f2f;
            font-weight: 600;
        }
        .attendance {
            font-size: 10pt;
            margin-bottom: 12px;
            padding: 8px;
            background: #f8f9fa;
            border-radius: 5px;
        }
        .attendance p {
            margin: 3px 0;
        }
        .comments {
            margin-bottom: 15px;
            font-size: 10pt;
        }
        .comments h3 {
            color: #004aad;
            margin-bottom: 6px;
        }
        .comments p {
            border: 1px solid #d1d5db;
            padding: 8px;
            min-height: 50px;
            background-color: #ffffff;
            border-radius: 4px;
        }
        .signatures {
            display: flex;
            justify-content: space-between;
            margin-top: 20px;
            font-size: 10pt;
        }
        .signature-box {
            width: 30%;
            text-align: center;
        }
        .signature-line {
            border-top: 2px solid #333;
            margin-bottom: 6px;
            height: 2em;
        }
        .header, .student-info, .grades-table, .general-results, .attendance, .comments, .signatures {
            page-break-inside: avoid;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <div class="header-info">
                <h1>UNIPROG SCHOOL</h1>
                <p>BP 812, Yaoundé, Cameroun</p>
                <h2>Bulletin Scolaire</h2>
                <p>Année Scolaire : {{ date('Y') }}-{{ date('Y') + 1 }}</p>
            </div>
       
                <img src="https://via.placeholder.com/100x120.png?text=Photo+Élève" alt="Photo Élève" />
         
        </div>

        <div class="student-info">
            <p><strong>Nom :</strong> {{ $eleve->nom_eleve }}</p>
            <p><strong>Prénom :</strong> {{ $eleve->prenom_eleve }}</p>
            <p><strong>Classe :</strong> {{ $classe->nom_classe }}</p>
            <p><strong>Date de Naissance :</strong> {{ $eleve->date_naiss }}</p>
        </div>

        <h3>Résultats par Matière</h3>
        <table class="grades-table">
            <thead>
                <tr>
                    <th>Matière</th>
                    <th>Moyenne</th>
                    <th>Appréciation</th>
                </tr>
            </thead>
            <tbody>
                @foreach($notes->groupBy('matiere.nom_matiere') as $matiereNom => $notesMatiere)
                    @php
                        $moyenneMatiere = $notesMatiere->avg('note');
                    @endphp
                    <tr>
                        <td>{{ $matiereNom }}</td>
                        <td>{{ number_format($moyenneMatiere, 2) }}</td>
                        <td>
                            @if($moyenneMatiere >= 16)
                                Très Bien
                            @elseif($moyenneMatiere >= 14)
                                Bien
                            @elseif($moyenneMatiere >= 12)
                                Assez Bien
                            @elseif($moyenneMatiere >= 10)
                                Passable
                            @else
                                Insuffisant
                            @endif
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="general-results">
            <p><strong>Moyenne Générale :</strong> {{ number_format($moyenneGenerale, 2) }}</p>
            <p><strong>Mention :</strong> <span class="mention">
                @if($moyenneGenerale >= 16)
                    Très Bien
                @elseif($moyenneGenerale >= 14)
                    Bien
                @elseif($moyenneGenerale >= 12)
                    Assez Bien
                @elseif($moyenneGenerale >= 10)
                    Passable
                @else
                    Insuffisant
                @endif
            </span></p>
        </div>

        @if(isset($absences) && $absences->isNotEmpty())
            <div class="attendance">
                <h3>Assiduité</h3>
                <p><strong>Total Absences Justifiées :</strong> {{ $absences->where('motif', 'justifiée')->count() }}</p>
                <p><strong>Total Absences Non Justifiées :</strong> {{ $absences->where('motif', 'non justifiée')->count() }}</p>
            </div>
        @endif

        <div class="comments">
            <h3>Appréciation Générale</h3>
            <p>{{ $commentaire_general ?? 'Encourager l’élève à maintenir ses efforts et à travailler régulièrement pour progresser.' }}</p>
        </div>

        <div class="signatures">
            <div class="signature-box">
                <div class="signature-line"></div>
                <p>Signature du Professeur Principal</p>
            </div>
            <div class="signature-box">
                <div class="signature-line"></div>
                <p>Signature du Directeur</p>
            </div>
            <div class="signature-box">
                <div class="signature-line"></div>
                <p>Signature des Parents</p>
            </div>
        </div>
    </div>
</body>
</html>