<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GestionSchool</title>

    <!-- CSS locaux via asset() -->
    <link href="{{ asset('ani/css/app.css') }}" rel="stylesheet">
    <link href="{{ asset('ani/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('ani/css/style.css') }}" rel="stylesheet">
    <style>
        html, body {
            margin: 0;
            padding: 0;
            height: 100vh;
            width: 100vw;
            overflow: hidden;
        }
    </style>
</head>

<body>

    <!-- Card occupant tout l'écran -->
    <div class="card" style="width: 100vw; height: 100vh; margin: 0; padding: 0; border: none; border-radius: 0;">
        <div class="card-header bg-primary text-white" style="font-size: 18px; font-weight: bold; margin: 0; border-radius: 0;">
            Gestion Scolaire
        </div>
        <div class="card-body" style="height: calc(100vh - 56px); margin: 0; padding: 15px; overflow-y: auto;">

            <!-- Messages flash (succès/erreur) -->
            @if (session('success'))
                <div class="alert alert-success">
                    {{ session('success') }}
                </div>
            @endif

            @if (session('error'))
                <div class="alert alert-danger">
                    {{ session('error') }}
                </div>
            @endif

            <!-- Contenu des pages -->
            @yield('content')
        </div>
    </div>

    <!-- Scripts -->
    <script src="{{ asset('ani/js/bootstrap.bundle.min.js') }}"></script>
</body>

</html>