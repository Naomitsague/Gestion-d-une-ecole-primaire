@extends('layouts')

@section('title', 'Gestion des Élèves')

@section('content')
    <div class="container d-flex justify-content-center align-items-center min-vh-100">
        <div class="glass-card text-center shadow-lg p-5">
            <h1 class="header-title mb-5">📚 Gestion des Élèves</h1>

            <div class="d-flex flex-column align-items-center gap-4">
                <a href="{{ url('/students/create') }}" class="btn btn-success btn-lg w-100">
                    <i class="bi bi-person-plus-fill me-2"></i>Créer un nouvel élève
                </a>
                <a href="{{ url('/students') }}" class="btn btn-primary btn-lg w-100">
                    <i class="bi bi-people-fill me-2"></i>Liste des élèves
                </a>
            </div>
        </div>
    </div>

    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .glass-card {
            background-color: #ffffffcc;
            border-radius: 16px;
            max-width: 500px;
            width: 100%;
        }

        .header-title {
            font-size: 2rem;
            font-weight: bold;
            color: #212529;
        }

        .btn-lg {
            font-size: 1.1rem;
            font-weight: 500;
            border-radius: 12px;
            transition: all 0.3s ease;
        }

        .btn-lg:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.1);
        }
    </style>
@endsection
